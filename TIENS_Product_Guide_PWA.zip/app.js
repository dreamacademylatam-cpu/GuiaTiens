/** @jsx React.createElement */
const { useMemo, useState, useRef, useEffect } = React;

const PEN = (n) => `S/ ${Number(n || 0).toFixed(2)}`;
const safeOpen = (url) => {
  const w = window.open(url, "_blank", "noopener,noreferrer");
  if (!w) alert("Permite ventanas emergentes para abrir WhatsApp o imprimir.");
};

const ALL_CATEGORIES = [
  { id: "todos", name: "Todos" },
  { id: "suplementos", name: "Suplementos" },
  { id: "bebidas", name: "Bebidas" },
  { id: "cuidadoPersonal", name: "Cuidado personal" }
];

const ALL_CONDITIONS = [
  { id: "", name: "Todas" },
  { id: "inmunidad", name: "🛡️ Inmunidad" },
  { id: "peso", name: "⚖️ Peso" },
  { id: "gastritis", name: "🫃 Gastritis" },
  { id: "vph", name: "🦠 VPH" },
  { id: "diabetes", name: "🩸 Diabetes" },
  { id: "osteoporosis", name: "🦴 Huesos" },
  { id: "cardiovascular", name: "❤️ Cardiovascular" },
  { id: "articulaciones", name: "🦵 Articulaciones" },
  { id: "energia", name: "⚡ Energía" },
  { id: "salud-bucal", name: "🦷 Salud bucal" },
];

const useDebounced = (value, ms = 250) => {
  const [v, setV] = useState(value);
  const t = useRef();
  useEffect(() => {
    clearTimeout(t.current);
    t.current = setTimeout(() => setV(value), ms);
    return () => clearTimeout(t.current);
  }, [value, ms]);
  return v;
};

function App() {
  const [selectedCategory, setSelectedCategory] = useState("todos");
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCondition, setSelectedCondition] = useState("");
  const [showPublicPrice, setShowPublicPrice] = useState(false);
  const debouncedSearch = useDebounced(searchTerm, 250);

  const productsEntries = useMemo(() => Object.entries(window.PRODUCTS || {}), []);
  const getPrice = (p) => (showPublicPrice ? p.pricePublico : p.priceAfiliado);

  const filteredProducts = useMemo(() => {
    const q = debouncedSearch.trim().toLowerCase();
    return productsEntries.filter(([key, p]) => {
      const byCat = selectedCategory === "todos" || p.category === selectedCategory;
      const blob = [
        p.name, p.codigo, p.ingredients, ...(p.benefits || [])
      ].join(" ").toLowerCase();
      const bySearch = !q || blob.includes(q);
      const byCond = !selectedCondition || (p.conditions || []).includes(selectedCondition);
      return byCat && bySearch && byCond;
    });
  }, [productsEntries, selectedCategory, debouncedSearch, selectedCondition]);

  const compartirProducto = (key) => {
    const p = (window.PRODUCTS || {})[key];
    if (!p) return;
    const priceType = showPublicPrice ? "Público" : "Afiliado";
    const msg = `🌟 *PRODUCTO TIENS PERÚ* 🌟

*${p.name}*
📝 Código: ${p.codigo}
💰 Precio ${priceType}: ${PEN(getPrice(p))}
⭐ Puntos: ${p.puntos}
📦 Presentación: ${p.presentation || "N/A"}

✨ *BENEFICIOS:*
${(p.benefits || []).map((b) => `• ${b}`).join("\n")}

💊 *DOSIFICACIÓN:*
${p.dosage || "Ver indicaciones del envase"}

⚠️ *PRECAUCIONES:*
${p.precautions || "Si presenta condiciones médicas, consulte a su profesional de salud."}

✅ *TIENS PERÚ 2025*
📞 Contáctame para tu pedido
🇵🇪 100% Original`;

    safeOpen(`https://wa.me/?text=${encodeURIComponent(msg)}`);
  };

  const generarPDFProducto = (key) => {
    const p = (window.PRODUCTS || {})[key];
    if (!p) return;
    const priceType = showPublicPrice ? "Público" : "Afiliado";
    const html = `<!doctype html><html><head><meta charset="utf-8"/>
<title>${p.name} - TIENS PERÚ</title>
<style>
 body{font-family:Arial,Helvetica,sans-serif;margin:32px;line-height:1.5}
 .hdr{background:linear-gradient(135deg,#10b981,#3b82f6);color:#fff;padding:24px;border-radius:12px;margin-bottom:24px}
 .pill{background:#dbeafe;color:#1e40af;border-radius:999px;padding:6px 12px;display:inline-block;font-weight:700}
 .price{font-size:28px;font-weight:800;color:#7c3aed;margin:8px 0}
 .sec{margin:20px 0;padding:16px;border-left:4px solid #10b981;background:#f0fdf4;border-radius:8px}
 .sec.blue{border-left-color:#3b82f6;background:#eff6ff}
 .sec.vio{border-left-color:#8b5cf6;background:#f5f3ff}
 .warn{background:#fef3c7;border-left:4px solid #f59e0b;padding:14px;border-radius:6px}
 ul{padding-left:18px}
</style></head><body>
<div class="hdr"><h1>🌟 TIENS PERÚ 2025 🌟</h1><p>Ficha de Producto</p></div>
<div style="text-align:center">
 <span class="pill">${p.codigo}</span>
 <h2 style="margin:12px 0">${p.name}</h2>
 <div class="price">Precio ${priceType}: ${PEN(getPrice(p))}</div>
 <p>⭐ ${p.puntos} pts | 📦 ${p.presentation || "N/A"}</p>
</div>
<div class="sec"><h3>✨ Beneficios</h3>
  <ul>${(p.benefits||[]).map(b=>`<li>${b}</li>`).join("")}</ul>
</div>
<div class="sec blue"><h3>💊 Dosificación</h3><p>${p.dosage || "Ver indicaciones del envase"}</p></div>
<div class="sec vio"><h3>🧪 Ingredientes</h3><p>${p.ingredients || "—"}</p></div>
<div class="warn"><strong>⚠️ Precauciones</strong><br>${p.precautions || "Si presenta condiciones médicas, consulte a su profesional de salud. No sustituye tratamiento médico."}</div>
<p style="margin-top:28px;font-size:12px;color:#555">Este material es informativo para distribuidores. No reemplaza consejo médico.</p>
</body></html>`;

    const w = window.open("", "_blank");
    if (!w) return alert("Permite ventanas emergentes para imprimir o guardar.");
    w.document.write(html);
    w.document.close();
    w.focus();
    w.print();
  };

  return (
    <div className="max-w-7xl mx-auto">
      {/* Hero */}
      <div className="bg-gradient-to-r from-green-600 to-blue-600 rounded-xl shadow-2xl p-6 mb-6 text-white">
        <div className="flex items-center justify-between mb-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="inline-flex items-center justify-center w-6 h-6 bg-white/20 rounded">📍</span>
              <span className="text-sm bg-white/20 px-3 py-1 rounded-full">PERÚ</span>
            </div>
            <h1 className="text-3xl md:text-4xl font-bold">Guía TIENS Perú 2025</h1>
            <p className="text-blue-100 mt-2">Comparte por WhatsApp o genera PDF</p>
          </div>
          <div className="text-5xl opacity-80">💚</div>
        </div>

        <div className="relative mb-3">
          <span className="absolute left-3 top-2.5">🔎</span>
          <input
            type="text"
            placeholder="Buscar por nombre, código, ingrediente o beneficio…"
            className="w-full pl-10 pr-4 py-3 rounded-lg text-gray-800"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        <div className="flex items-center justify-center gap-3">
          <button
            onClick={() => setShowPublicPrice(false)}
            className={`px-4 py-2 rounded-lg font-semibold transition-all ${!showPublicPrice ? "bg-white text-green-600" : "bg-white/20"}`}
          >
            Afiliado
          </button>
          <button
            onClick={() => setShowPublicPrice(true)}
            className={`px-4 py-2 rounded-lg font-semibold transition-all ${showPublicPrice ? "bg-white text-green-600" : "bg-white/20"}`}
          >
            Público
          </button>
        </div>
      </div>

      {/* Filtros */}
      <div className="bg-white rounded-xl shadow-lg p-4 mb-6">
        <div className="mb-3">
          <p className="text-sm text-gray-600 mb-2">Categorías:</p>
          <div className="flex flex-wrap gap-2">
            {ALL_CATEGORIES.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-3 py-1 rounded-full text-sm font-medium ${selectedCategory === cat.id ? "bg-green-600 text-white" : "bg-gray-100 text-gray-700"}`}
              >
                {cat.name}
              </button>
            ))}
          </div>
        </div>

        <div>
          <p className="text-sm text-gray-600 mb-2">Condiciones:</p>
          <div className="flex flex-wrap gap-2">
            {ALL_CONDITIONS.map((cond) => (
              <button
                key={cond.id}
                onClick={() => setSelectedCondition(cond.id)}
                className={`px-3 py-1 rounded-full text-sm font-medium ${selectedCondition === cond.id ? "bg-blue-600 text-white" : "bg-gray-100 text-gray-700"}`}
              >
                {cond.name}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Lista + Detalle */}
      <div className="grid lg:grid-cols-2 gap-6">
        <div className="space-y-3">
          <h2 className="text-2xl font-bold text-gray-800">Catálogo ({filteredProducts.length})</h2>
          <div className="space-y-3 max-h-[700px] overflow-y-auto pr-2">
            {filteredProducts.map(([key, p]) => (
              <div
                key={key}
                className={`bg-white card p-4 cursor-pointer transition-all`}
                onClick={() => setSelectedProduct(key)}
              >
                <div className="flex justify-between mb-2">
                  <div className="flex-1">
                    <div className="flex gap-2 mb-1">
                      <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded font-bold">{p.codigo}</span>
                      <span className="text-xs bg-purple-100 text-purple-800 px-2 py-1 rounded">{p.puntos} pts</span>
                    </div>
                    <h3 className="font-bold text-lg text-green-700">{p.name}</h3>
                    <p className="text-xl text-purple-600 font-bold">{PEN(getPrice(p))}</p>
                  </div>
                </div>

                <div className="flex flex-wrap gap-1 mb-3">
                  {(p.benefits || []).slice(0, 2).map((b, i) => (
                    <span key={i} className="text-xs bg-green-50 text-green-700 px-2 py-1 rounded">✓ {b}</span>
                  ))}
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={(e) => { e.stopPropagation(); compartirProducto(key); }}
                    className="bg-green-600 text-white py-2 px-3 rounded-lg hover:bg-green-700 transition-all flex items-center justify-center gap-1 text-sm font-semibold"
                  >
                    📤 WhatsApp
                  </button>
                  <button
                    onClick={(e) => { e.stopPropagation(); generarPDFProducto(key); }}
                    className="bg-blue-600 text-white py-2 px-3 rounded-lg hover:bg-blue-700 transition-all flex items-center justify-center gap-1 text-sm font-semibold"
                  >
                    ⬇️ PDF
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div>
          {selectedProduct ? (
            <div className="bg-white rounded-xl shadow-xl p-6 sticky top-4">
              {(() => {
                const p = (window.PRODUCTS || {})[selectedProduct];
                return (
                  <>
                    <div className="mb-4">
                      <span className="text-sm bg-blue-100 text-blue-800 px-3 py-1 rounded-full font-bold">{p.codigo}</span>
                      <h2 className="text-2xl font-bold text-green-700 mt-2">{p.name}</h2>
                      <p className="text-2xl text-purple-600 font-bold mt-1">{PEN(getPrice(p))}</p>
                      <p className="text-sm text-gray-600">{p.presentation || "Presentación: n/a"}</p>
                    </div>

                    <div className="space-y-4 max-h-[500px] overflow-y-auto pr-2 mb-4">
                      <div className="bg-purple-50 p-4 rounded-lg border border-purple-200">
                        <h3 className="font-bold mb-2 text-purple-900">🧪 INGREDIENTES</h3>
                        <p className="text-sm text-gray-800">{p.ingredients || "—"}</p>
                      </div>

                      <div className="bg-gradient-to-r from-green-50 to-emerald-50 p-4 rounded-lg border border-green-200">
                        <h3 className="font-bold mb-3 text-green-900 text-lg">
                          ✨ BENEFICIOS ({(p.benefits || []).length})
                        </h3>
                        <ul className="space-y-2">
                          {(p.benefits || []).map((b, i) => (
                            <li key={i} className="flex items-start bg-white p-3 rounded-lg shadow-sm">
                              <span className="text-green-600 mr-2 text-lg font-bold">✓</span>
                              <span className="text-sm text-gray-800 font-medium">{b}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                      <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                        <h3 className="font-bold mb-3 text-blue-900">💊 DOSIFICACIÓN</h3>
                        <div className="bg-white p-3 rounded-lg">
                          <p className="text-sm text-gray-800 leading-relaxed">{p.dosage || "Ver indicaciones del envase"}</p>
                        </div>
                      </div>

                      <div className="bg-yellow-50 p-4 rounded-lg border-l-4 border-yellow-500">
                        <h3 className="font-bold mb-3 flex items-center text-yellow-900">
                          ⚠️ PRECAUCIONES
                        </h3>
                        <p className="text-sm text-gray-800 font-medium">
                          {p.precautions || "Si presenta condiciones médicas, consulte a su profesional de salud. No sustituye tratamiento médico."}
                        </p>
                      </div>

                      {(p.conditions || []).length > 0 && (
                        <div className="bg-indigo-50 p-4 rounded-lg border border-indigo-200">
                          <h3 className="font-bold mb-3 text-indigo-900">🎯 IDEAL PARA:</h3>
                          <div className="flex flex-wrap gap-2">
                            {(p.conditions || []).map((cond, i) => {
                              const label = (ALL_CONDITIONS.find(c => c.id === cond) || {}).name || cond;
                              return (
                                <span key={i} className="bg-indigo-200 text-indigo-900 px-3 py-1 rounded-full text-xs font-semibold">
                                  {label}
                                </span>
                              );
                            })}
                          </div>
                        </div>
                      )}
                    </div>

                    <div className="grid grid-cols-2 gap-3 mt-4">
                      <button
                        onClick={() => compartirProducto(selectedProduct)}
                        className="bg-green-600 text-white py-3 px-4 rounded-lg font-semibold hover:bg-green-700 transition-all flex items-center justify-center gap-2"
                      >
                        📤 WhatsApp
                      </button>
                      <button
                        onClick={() => generarPDFProducto(selectedProduct)}
                        className="bg-blue-600 text-white py-3 px-4 rounded-lg font-semibold hover:bg-blue-700 transition-all flex items-center justify-center gap-2"
                      >
                        ⬇️ PDF
                      </button>
                    </div>
                  </>
                );
              })()}
            </div>
          ) : (
            <div className="bg-white rounded-xl shadow-lg p-12 text-center sticky top-4">
              <div className="text-6xl text-gray-300 mb-3">ℹ️</div>
              <p className="text-gray-500">Selecciona un producto</p>
            </div>
          )}
        </div>
      </div>

      <div className="mt-6 text-xs text-gray-500">
        Herramienta informativa para distribuidores TIENS. No reemplaza consejo médico.
      </div>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);